library(testthat)
library(mysparsegl)

test_check("mysparsegl")
